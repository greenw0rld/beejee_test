<?php
          $db = new mysqli("heal2me.com", "admhealme", "C&Lc^E}v(UOf", "beejee"); 
       ?>