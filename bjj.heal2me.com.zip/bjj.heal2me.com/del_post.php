<?php
include("bd.php");
$del_id = $_POST['del_id'];
$resu = mysqli_query ($db,"DELETE FROM post WHERE id = '$del_id'");  
?>