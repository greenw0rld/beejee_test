<?php
        if (isset($_POST['post1'])) { $post1=$_POST['post1']; if ($post1 =='') { unset($post1);} }
		if (isset($_POST['name'])) { $name=$_POST['name']; if ($name =='') { unset($name);} }
		if (isset($_POST['email'])) { $email=$_POST['email']; if ($email =='') { unset($email);} }
		$date = date( "H:i:s d.m.y" );
		include("bd.php");
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		 $resu = mysqli_query ($db,"INSERT INTO post (user,email,post,date) VALUES('$name','$email','$post1','$date')"); 
         }
         else
         {
         header("Status: 0");       
         }
?>