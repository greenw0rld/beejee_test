<?php
session_start();
include("bd.php");
$change_id = $_POST['change_id'];
$post = $_POST['post'];
$otredacheno = $_POST['otredacheno'];
$adm_check = $_SESSION['login'];
$status = 'Выполнено<br>Отредактировано Админом';
$res = mysqli_query ($db,"UPDATE post SET status = '$status', adm_check = '$adm_check',post = '$post' WHERE id = '$change_id'");
?>