<?php
        session_start();
        if (isset($_POST['login'])) { $login = $_POST['login']; if ($login == '') { unset($login);} }
        if (isset($_POST['password'])) { $password=$_POST['password']; if ($password =='') { unset($password);} }        
        $login = stripslashes($login);
        $login = htmlspecialchars($login);
        $password = stripslashes($password);
        $password = htmlspecialchars($password);
        $login = trim($login);
        $password = trim($password);
        include ("bd.php");
        $result = mysqli_query($db,"SELECT login,password FROM admins WHERE login='$login'");
        $myrow = mysqli_fetch_array($result);
        $password_m = $myrow['password'];
        if ($password_m == $password) {
        $_SESSION['login']= $myrow['login'];
        }
        else
        {
        header("Status: 0");    
        }
?>      
